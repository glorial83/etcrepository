package com.okihouse.vo;

import lombok.Data;

@Data
public class SuccessVO {

	private int code = 0;
	private String message = "success";

}
