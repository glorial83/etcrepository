package cz.sidik.demo.oraclemybatis;

import org.junit.Ignore;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractTransactionalJUnit4SpringContextTests;

/**
 * Created by msida on 26.9.2016.
 */
@ContextConfiguration("classpath:cz/sidik/demo/oraclemybatis/spring-config.xml")
@Ignore
public class BaseMapperTest extends AbstractTransactionalJUnit4SpringContextTests {
}
