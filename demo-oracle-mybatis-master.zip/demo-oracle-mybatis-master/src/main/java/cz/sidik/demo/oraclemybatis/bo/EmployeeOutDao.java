package cz.sidik.demo.oraclemybatis.bo;

/**
 * Created by msida on 20.9.2016.
 */
public class EmployeeOutDao extends EmployeeDao {
    public String oldName;
}
