package cz.sidik.demo.oraclemybatis.bo;

/**
 * Created by msida on 26.9.2016.
 */
public class EmployeeDao {
    public Long employeeId;
    public String firstName;
    public String lastName;

}
