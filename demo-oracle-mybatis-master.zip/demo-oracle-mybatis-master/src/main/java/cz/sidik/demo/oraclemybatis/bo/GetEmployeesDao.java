package cz.sidik.demo.oraclemybatis.bo;

import java.util.Collection;

/**
 * Created by msida on 26.9.2016.
 */
public class GetEmployeesDao {
    public Long departmentId;
    public Collection<EmployeeDao> employees;
}
