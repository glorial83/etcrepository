DROP FUNCTION set_employee_name;

DROP PROCEDURE set_employee_name_out;

DROP FUNCTION get_employee_name;

DROP FUNCTION get_employees;

DROP PROCEDURE get_employees_out;

DROP PROCEDURE insert_employees;

DROP FUNCTION get_employees_array;

DROP PROCEDURE get_employees_array_out;

DROP FUNCTION pipe_employees_cursor;

DROP TYPE employee_arraytype;

DROP TYPE employee_structtype;


